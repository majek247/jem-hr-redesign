import { Link } from 'react-router-dom'

const columns = [
  {
    heading: 'Platform',
    links: [
      { label: 'Connect', to: '/product' },
      { label: 'Manage', to: '/product' },
      { label: 'Reward', to: '/product' },
      { label: 'Industries', to: '/solutions' },
    ],
  },
  {
    heading: 'Stories',
    links: [
      { label: 'Customers', to: '/customers' },
      { label: 'Case studies', to: '/customers' },
      { label: 'Testimonials', to: '/customers' },
    ],
  },
  {
    heading: 'Company',
    links: [
      { label: 'About Jem', to: '/about' },
      { label: 'Careers', to: '/careers' },
      { label: 'Contact', to: '/contact' },
    ],
  },
]

export default function Footer() {
  return (
    <footer className="bg-ink text-paper/80">
      <div className="container-content py-16">
        <div className="grid gap-12 md:grid-cols-[1.3fr_1fr_1fr_1fr]">
          <div>
            <Link to="/" className="flex items-center gap-2">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-coral text-paper font-display text-lg italic">
                j
              </span>
              <span className="font-display text-xl italic text-paper">jem</span>
            </Link>
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-paper/60">
              The workforce platform for deskless teams, built on WhatsApp.
            </p>
          </div>

          {columns.map((col) => (
            <div key={col.heading}>
              <h4 className="font-display text-base italic text-paper/90">{col.heading}</h4>
              <ul className="mt-4 space-y-3 text-sm">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <Link to={link.to} className="text-paper/60 transition-colors hover:text-coral">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-16 flex flex-col gap-4 border-t border-paper/10 pt-8 text-xs text-paper/45 md:flex-row md:items-center md:justify-between">
          <p>&copy; {new Date().getFullYear()} Jem. All rights reserved.</p>
          <div className="flex gap-6">
            <Link to="/" className="hover:text-paper/70">Terms</Link>
            <Link to="/" className="hover:text-paper/70">Privacy</Link>
            <Link to="/" className="hover:text-paper/70">Cookies</Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
