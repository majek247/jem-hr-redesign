import { useEffect, useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import Button from './Button'
import { navLinks } from '../lib/data'

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header className="sticky top-0 z-50">
      <div className="bg-ink text-paper/90 text-sm">
        <div className="container-content flex items-center justify-center gap-3 py-2 text-center">
          <span>Jem 2.0 has landed</span>
          <Link to="/about" className="underline underline-offset-4 decoration-coral hover:text-coral">
            See what changed
          </Link>
        </div>
      </div>

      <div
        className={`transition-all duration-300 ${
          scrolled ? 'bg-paper/95 backdrop-blur shadow-soft' : 'bg-paper'
        }`}
      >
        <nav className="container-content flex items-center justify-between py-4">
          <Link to="/" className="flex items-center gap-2" onClick={() => setOpen(false)}>
            <span className="grid h-9 w-9 place-items-center rounded-full bg-coral text-paper font-display text-lg italic">
              j
            </span>
            <span className="font-display text-xl italic text-ink">jem</span>
          </Link>

          <div className="hidden items-center gap-9 md:flex">
            {navLinks.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                className={({ isActive }) =>
                  `text-[0.95rem] transition-colors ${
                    isActive ? 'text-coral' : 'text-ink/75 hover:text-ink'
                  }`
                }
              >
                {link.label}
              </NavLink>
            ))}
          </div>

          <div className="hidden md:block">
            <Button to="/contact" variant="dark">
              Book a demo
            </Button>
          </div>

          <button
            className="grid h-10 w-10 place-items-center rounded-full border border-ink/15 md:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-label="Toggle menu"
            aria-expanded={open}
          >
            <span className="relative block h-3 w-4">
              <span
                className={`absolute left-0 top-0 h-[1.5px] w-4 bg-ink transition-transform ${
                  open ? 'translate-y-[5px] rotate-45' : ''
                }`}
              />
              <span
                className={`absolute left-0 bottom-0 h-[1.5px] w-4 bg-ink transition-transform ${
                  open ? '-translate-y-[5px] -rotate-45' : ''
                }`}
              />
            </span>
          </button>
        </nav>

        {open && (
          <div className="border-t border-ink/10 bg-paper md:hidden">
            <div className="container-content flex flex-col gap-5 py-6">
              {navLinks.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  onClick={() => setOpen(false)}
                  className="text-lg text-ink/85"
                >
                  {link.label}
                </NavLink>
              ))}
              <Button to="/contact" variant="primary" className="mt-2 w-full">
                Book a demo
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
