import { useState } from 'react'
import Section from '../components/Section'
import Button from '../components/Button'
import LogoMarquee from '../components/LogoMarquee'
import {
  pillars,
  steps,
  stats,
  caseStudy,
  testimonial,
  securityBadges,
  execReasons,
} from '../lib/data'

function ChatMock() {
  return (
    <div className="relative mx-auto w-full max-w-sm">
      <div className="absolute -left-10 -top-10 h-40 w-40 rounded-full bg-mist blur-2xl" />
      <div className="absolute -bottom-12 -right-8 h-44 w-44 rounded-full bg-coral-light blur-2xl" />

      <div className="relative rounded-xl2 border border-ink/10 bg-white/90 p-4 shadow-soft backdrop-blur">
        <div className="flex items-center gap-2 border-b border-ink/10 pb-3">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-coral text-sm font-semibold text-paper">
            j
          </span>
          <div>
            <p className="text-sm font-semibold text-ink">Jem</p>
            <p className="text-xs text-palm">online via WhatsApp</p>
          </div>
        </div>

        <div className="mt-4 space-y-3">
          <div className="max-w-[85%] rounded-2xl rounded-tl-sm bg-sand px-4 py-3 text-sm text-ink/85">
            Your October payslip is ready.
            <div className="mt-2 inline-block rounded-full bg-ink px-3 py-1 text-xs text-paper">
              View payslip
            </div>
          </div>

          <div className="ml-auto max-w-[70%] rounded-2xl rounded-tr-sm bg-coral px-4 py-3 text-sm text-paper">
            Got it, thank you
          </div>

          <div className="max-w-[85%] rounded-2xl rounded-tl-sm bg-sand px-4 py-3 text-sm text-ink/85">
            Quick one — how was your shift today?
            <div className="mt-2 flex gap-2 text-xs">
              <span className="rounded-full border border-ink/15 px-3 py-1">Good</span>
              <span className="rounded-full border border-ink/15 px-3 py-1">Okay</span>
              <span className="rounded-full border border-ink/15 px-3 py-1">Tough</span>
            </div>
          </div>

          <div className="max-w-[85%] rounded-2xl rounded-tl-sm border border-palm/30 bg-palm/10 px-4 py-3 text-sm text-ink/85">
            You have <span className="font-semibold">R850</span> in earned wages available.
            <div className="mt-2 inline-block rounded-full bg-palm px-3 py-1 text-xs text-paper">
              Withdraw now
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function ExecReasons() {
  const [active, setActive] = useState(0)
  const current = execReasons[active]

  return (
    <Section>
      <div className="grid gap-12 md:grid-cols-[0.85fr_1.15fr]">
        <div>
          <h2 className="font-display text-3xl italic text-ink md:text-4xl">
            A case for every seat at the table
          </h2>
          <p className="mt-4 max-w-sm text-ink/65">
            Jem earns its place on more than one budget line. Choose a seat to see the argument
            that matters most from where you sit.
          </p>

          <div className="mt-8 flex flex-col gap-1">
            {execReasons.map((reason, i) => (
              <button
                key={reason.role}
                onClick={() => setActive(i)}
                className={`rounded-xl px-4 py-3 text-left transition-colors ${
                  active === i ? 'bg-ink text-paper' : 'text-ink/60 hover:bg-sand'
                }`}
              >
                <span className="block text-sm">{reason.role}</span>
                <span
                  className={`block text-xs ${active === i ? 'text-paper/60' : 'text-ink/40'}`}
                >
                  {reason.label}
                </span>
              </button>
            ))}
          </div>
        </div>

        <div className="rounded-xl2 bg-white p-8 shadow-soft md:p-10">
          <h3 className="font-display text-2xl italic text-ink">{current.headline}</h3>
          <p className="mt-4 text-ink/65">{current.body}</p>
          <ul className="mt-6 space-y-3">
            {current.points.map((point) => (
              <li key={point} className="flex gap-3 text-sm text-ink/75">
                <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-coral" />
                {point}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Section>
  )
}

export default function Home() {
  return (
    <>
      <Section className="pb-14 pt-14 md:pt-20">
        <div className="grid items-center gap-14 md:grid-cols-2">
          <div>
            <h1 className="font-display text-4xl italic leading-[1.08] text-ink md:text-6xl">
              Africa's deskless workforce, finally seen.
            </h1>
            <p className="mt-6 max-w-md text-lg text-ink/65">
              Jem turns WhatsApp into a full HR and financial-wellbeing platform for the people
              who keep your business running — no app to download, nothing to train.
            </p>
            <div className="mt-9 flex flex-wrap gap-4">
              <Button to="/contact">Book a demo</Button>
              <Button to="/product" variant="ghost">
                See it in action
              </Button>
            </div>
            <p className="mt-8 text-sm text-ink/45">
              Trusted by 200+ employers and 250,000+ deskless workers across Africa.
            </p>
          </div>
          <ChatMock />
        </div>
      </Section>

      <LogoMarquee />

      <ExecReasons />

      <Section className="bg-ink text-paper" bleed>
        <div className="container-content">
          <div className="max-w-xl">
            <h2 className="font-display text-3xl italic md:text-4xl">
              One frontline. Three jobs done properly.
            </h2>
            <p className="mt-4 text-paper/60">
              Communication, HR operations and financial benefits, running on the app your
              people already open every day.
            </p>
          </div>

          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {pillars.map((pillar) => (
              <div
                key={pillar.key}
                className="flex flex-col justify-between rounded-xl2 border border-paper/10 bg-paper/5 p-8"
              >
                <div>
                  <span
                    className={`inline-block h-2.5 w-2.5 rounded-full ${
                      pillar.color === 'coral'
                        ? 'bg-coral'
                        : pillar.color === 'palm'
                        ? 'bg-palm'
                        : 'bg-paper'
                    }`}
                  />
                  <h3 className="mt-4 font-display text-2xl italic">{pillar.title}</h3>
                  <p className="mt-2 text-sm text-paper/55">{pillar.tagline}</p>
                  <p className="mt-4 text-sm leading-relaxed text-paper/65">
                    {pillar.description}
                  </p>
                </div>
                <ul className="mt-8 space-y-2.5 border-t border-paper/10 pt-6">
                  {pillar.points.map((point) => (
                    <li key={point} className="text-sm text-paper/60">
                      {point}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </Section>

      <Section>
        <div className="grid gap-14 md:grid-cols-[0.9fr_1.1fr] md:items-center">
          <div>
            <h2 className="font-display text-3xl italic text-ink md:text-4xl">
              Live in three steps
            </h2>
            <p className="mt-4 text-ink/65">
              Most employers are fully rolled out before their next payroll cycle.
            </p>
            <div className="mt-10 grid grid-cols-3 gap-4 rounded-xl2 bg-sand p-6">
              {stats.map((stat) => (
                <div key={stat.label}>
                  <p className="font-display text-2xl italic text-ink">{stat.value}</p>
                  <p className="mt-1 text-xs leading-snug text-ink/55">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>

          <ol className="space-y-6">
            {steps.map((step) => (
              <li
                key={step.number}
                className="flex gap-5 rounded-xl2 border border-ink/10 bg-white p-6"
              >
                <span className="font-display text-2xl italic text-coral">{step.number}</span>
                <div>
                  <h3 className="font-semibold text-ink">{step.title}</h3>
                  <p className="mt-1.5 text-sm text-ink/60">{step.description}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </Section>

      <Section className="bg-mist" bleed>
        <div className="container-content grid gap-12 md:grid-cols-2 md:items-center">
          <div className="rounded-xl2 bg-white p-8 shadow-soft md:p-10">
            <p className="font-display text-xl italic leading-relaxed text-ink md:text-2xl">
              "{testimonial.quote}"
            </p>
            <div className="mt-6">
              <p className="text-sm font-semibold text-ink">{testimonial.name}</p>
              <p className="text-sm text-ink/50">{testimonial.role}</p>
            </div>
          </div>

          <div className="rounded-xl2 bg-ink p-8 text-paper md:p-10">
            <p className="text-xs uppercase tracking-wide text-paper/45">Case study</p>
            <h3 className="mt-3 font-display text-2xl italic">{caseStudy.headline}</h3>
            <p className="mt-2 text-sm text-paper/50">{caseStudy.sector}</p>
            <p className="mt-4 text-sm leading-relaxed text-paper/65">{caseStudy.body}</p>
            <div className="mt-8 grid grid-cols-3 gap-4 border-t border-paper/10 pt-6">
              {caseStudy.metrics.map((metric) => (
                <div key={metric.label}>
                  <p className="font-display text-xl italic text-coral">{metric.value}</p>
                  <p className="mt-1 text-xs leading-snug text-paper/50">{metric.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Section>

      <Section>
        <div className="grid gap-10 md:grid-cols-[1.1fr_0.9fr] md:items-center">
          <div>
            <h2 className="font-display text-3xl italic text-ink md:text-4xl">
              Why Jem exists
            </h2>
            <p className="mt-5 max-w-lg text-ink/65">
              Three in four South African workers are deskless, yet almost none of enterprise
              software is built with them in mind. They're locked out of tools built for office
              staff, and often locked out of fair financial services too. Jem meets them where
              they already are, on their own terms — and we're building out from South Africa
              across the continent.
            </p>
            <div className="mt-8">
              <Button to="/about" variant="ghost">
                Our story
              </Button>
            </div>
          </div>

          <div className="rounded-xl2 border border-ink/10 bg-sand p-8">
            <p className="text-sm uppercase tracking-wide text-ink/40">Security your board signs off on</p>
            <ul className="mt-5 space-y-3">
              {securityBadges.map((badge) => (
                <li key={badge} className="flex items-center gap-3 text-sm text-ink/70">
                  <span className="h-1.5 w-1.5 rounded-full bg-palm" />
                  {badge}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Section>

      <Section className="bg-coral text-paper" bleed>
        <div className="container-content flex flex-col items-start gap-6 md:flex-row md:items-center md:justify-between">
          <h2 className="max-w-lg font-display text-3xl italic md:text-4xl">
            Watch your frontline fall into place.
          </h2>
          <div className="flex flex-wrap gap-4">
            <Button to="/contact" variant="dark">
              Book a demo
            </Button>
            <Button to="/product" variant="ghost" className="border-paper/40 text-paper hover:border-paper">
              See it in action
            </Button>
          </div>
        </div>
      </Section>
    </>
  )
}
